# BlockLauncher + Tile Render API

Fork de BlockLauncher (MCPELauncher) basado en la rama `tile-render-api` de byteandahalf,
preparado para compilarse con GitHub Actions.

El código fuente original está en `MCPELauncher/` (sin modificar). Lo nuevo de este repo:

- `.github/workflows/build.yml`: compila en GitHub y sube el APK como artefacto.
- `scripts/build.sh`: instala SDK r24.4.1 + NDK r10e, clona dependencias y ejecuta `ndk-build` y `ant`.

## Estado: SIN PROBAR

Este workflow se escribió sin poder ejecutarlo (sin red ni Ant/NDK donde se preparó). Es un
punto de partida: es probable que el primer run falle y haya que ajustar versiones o URLs.

## Lo que falta

El proyecto `MCPELauncher` es una **librería** (`android.library=true`). Para generar un APK
necesita la carpeta **`MCPELauncher-app`** (el wrapper de la app, con manifest, recursos y assets),
que no viene en el zip. Hay que añadirla en la raíz del repo antes de compilar.

## Qué agrega el tile render API

Frente a BlockLauncher 1.6.11, esta rama añade `nativeRenderStandardBlock`,
`nativeRenderCrossBlock`, `nativeRenderTorchBlock` y el hook `renderBlockHook`
para dibujar bloques personalizados desde scripts.

## Subir a GitHub

```bash
cd BlockLauncher-tile-render-api
git init -b main
git add .
git commit -m "Import BlockLauncher tile-render-api + CI"
git remote add origin https://github.com/TU_USUARIO/BlockLauncher-tile-render-api.git
git push -u origin main
```

Luego ve a la pestaña **Actions** del repo para ver el build.

## Créditos y licencias

Ver `MCPELauncher/thanks.txt` y `MCPELauncher/README.md` (zhuowei, byteandahalf, aFileChooser,
libsuperuser, Rhino, PTPatch, etc.). Respeta las licencias de cada proyecto.
