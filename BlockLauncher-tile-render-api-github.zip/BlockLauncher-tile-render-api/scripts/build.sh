#!/usr/bin/env bash
# Build de BlockLauncher (stack 2014: Ant + NDK r10e + Android SDK Tools r24.4.1).
# Pensado para correr en el CI de GitHub (necesita red). SIN PROBAR todavía: ver README.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEPS="$ROOT/deps"
mkdir -p "$DEPS"
cd "$DEPS"

# --- 1. Android SDK tools r24.4.1 (ultima version con soporte Ant) ---
if [ ! -d android-sdk-linux ]; then
  curl -fsSL -o sdk.tgz https://dl.google.com/android/android-sdk_r24.4.1-linux.tgz
  tar xzf sdk.tgz && rm sdk.tgz
fi
export ANDROID_SDK="$DEPS/android-sdk-linux"
export PATH="$ANDROID_SDK/tools:$ANDROID_SDK/platform-tools:$PATH"
yes | android update sdk --no-ui --all --filter platform-tools,build-tools-19.1.0,android-10,android-17,android-19 || true

# --- 2. NDK r10e ---
if [ ! -d android-ndk-r10e ]; then
  curl -fsSL -o ndk.bin https://dl.google.com/android/ndk/android-ndk-r10e-linux-x86_64.bin
  chmod +x ndk.bin && ./ndk.bin -y >/dev/null && rm ndk.bin
fi
export ANDROID_NDK="$DEPS/android-ndk-r10e"
export PATH="$ANDROID_NDK:$PATH"

# --- 3. Librerias que pide el README original ---
[ -d aFileChooser ]  || git clone --depth 1 https://github.com/zhuowei/aFileChooser.git
[ -d libsuperuser ]  || git clone --depth 1 https://github.com/Chainfire/libsuperuser.git

# --- 4. Layout que espera el README (carpetas hermanas) ---
rm -rf MCPELauncher && cp -r "$ROOT/MCPELauncher" MCPELauncher
rm -rf MCPELauncher-app
if [ -d "$ROOT/MCPELauncher-app" ]; then
  cp -r "$ROOT/MCPELauncher-app" MCPELauncher-app
else
  echo "ERROR: falta la carpeta MCPELauncher-app (el wrapper de la app) en $ROOT."
  echo "Ver README, seccion 'Lo que falta'."
  exit 1
fi

# --- 5. Codigo nativo ---
( cd MCPELauncher && ndk-build )

# --- 6. Proyectos Ant ---
android update lib-project -p libsuperuser/libsuperuser -t android-10
android update lib-project -p aFileChooser/aFileChooser -t android-10
android update project -p MCPELauncher -t android-10
android update project -p MCPELauncher-app -t android-17
( cd MCPELauncher-app && ant clean debug )
