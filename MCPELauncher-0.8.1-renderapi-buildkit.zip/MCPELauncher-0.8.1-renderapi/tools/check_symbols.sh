#!/usr/bin/env bash
# Comprueba que todos los simbolos que el launcher busca con dlsym existen en
# un libminecraftpe.so concreto (p. ej. el de Minecraft PE 0.8.1).
#
# Uso: bash tools/check_symbols.sh /ruta/a/libminecraftpe.so
set -euo pipefail
SO="${1:?Uso: $0 /ruta/a/libminecraftpe.so}"
JNI="$(cd "$(dirname "${BASH_SOURCE[0]}")/../jni" && pwd)"

readelf --dyn-syms -W "$SO" | awk '{print $8}' | sort -u > /tmp/_have.txt
# Ignora lineas comentadas (// ...)
cat "$JNI"/*.c "$JNI"/*.cpp | grep -v '^[[:space:]]*//' | grep -v '^[[:space:]]*/\?\*' \
  | grep -oE '"_Z[A-Za-z0-9_]+"' | tr -d '"' | sort -u > /tmp/_want.txt

echo "Simbolos buscados: $(wc -l < /tmp/_want.txt)"
MISSING="$(comm -23 /tmp/_want.txt /tmp/_have.txt)"
if [ -n "$MISSING" ]; then
  echo "FALTAN en esta version de libminecraftpe.so:"; echo "$MISSING"; exit 1
fi
echo "OK: todos los simbolos existen."
