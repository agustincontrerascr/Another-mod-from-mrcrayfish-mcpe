# Compilar BlockLauncher 0.8.1 + Render API

Este proyecto ya apunta a **Minecraft PE 0.8.1** (`MINECRAFT_VERSION_CODE = 500801011`)
e incluye la API de render de bloques (`BlockRenderer.renderBlock / renderCross / renderTorch`).

## Opcion A: GitHub Actions (sin instalar nada)

1. Crea un repositorio nuevo en GitHub y sube **todo el contenido** de esta carpeta
   (incluida la carpeta oculta `.github`). Con git:
   ```
   git init && git add -A && git commit -m "BlockLauncher 0.8.1 render api"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
   git push -u origin main
   ```
2. Ve a la pestaña **Actions** → "Build BlockLauncher 0.8.1 (Render API)". Se ejecuta solo
   con cada push; tambien puedes usar **Run workflow**.
3. Cuando termine (la primera vez tarda ~10-15 min), abre la ejecucion y descarga el
   artefacto **BlockLauncher-0.8.1-renderapi** (contiene el `.apk`).

## Opcion B: en tu PC (Ubuntu 20.04/22.04 x86_64)

```
sudo apt install openjdk-8-jdk      # y deja Java 8 como predeterminado
bash tools/build.sh
```
El APK queda en `out/BlockLauncher-0.8.1-renderapi-debug.apk`.
Todo lo demas (SDK, NDK r10e, dependencias) se descarga en `~/BLBUILD`.

## Que hace el script

1. Instala `ant`, `git`, `p7zip`, etc. y baja Android SDK tools r25.2.5, `android-19`, build-tools 25.0.3 y NDK r10e.
2. Copia este proyecto como `BLBUILD/MCPELauncher` y clona `MCPELauncher-app`, `aFileChooser`
   (rama `prefragments`) y `libsuperuser`, fijados a mayo de 2014 para que coincidan con este codigo.
3. `ndk-build` → `libmcpelauncher.so`; `android update project` + `ant clean debug` → APK.
4. Comprueba que el APK incluya `libmcpelauncher.so` y la clase `NativeBlockRendererApi`.

## Verificar simbolos contra tu Minecraft

```
bash tools/check_symbols.sh /ruta/a/libminecraftpe.so
```
(Con el `libminecraftpe.so` de 0.8.1 da OK: los 139 simbolos existen.)

## Si algo falla

- Cambia versiones sin tocar el script: `DEPS_BEFORE=2014-04-20`, `APP_REF=<commit>`,
  `SUPERUSER_REF=<commit>`, `ANDROID_TARGET=android-17`, etc. (ver cabecera de `tools/build.sh`).
- Pega el final del log del paso que fallo y lo arreglamos.
- Instalar el APK: es un build *debug*; desinstala antes cualquier BlockLauncher firmado con otra clave.
